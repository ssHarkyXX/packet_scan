from scapy.all import *


def packet_size_filter(size, packets, operator):
    if operator == "greater":
        filtered_packets = [pkt for pkt in packets if len(pkt) > size]
    elif operator == "less":
        filtered_packets = [pkt for pkt in packets if len(pkt) < size]
    else:
        print("Incorrect operator entered. Please choose 'greater' or 'less'.")
        return []

    return filtered_packets


def protocol_filter(packets, chosen_protocols):
    filtered_packets = []
    chosen_protocols_list = [proto.strip().upper() for proto in chosen_protocols.split(',')]

    for pkt in packets:
        for proto in chosen_protocols_list:
            if pkt.haslayer(proto):
                filtered_packets.append(pkt)
                break

    return filtered_packets


def main():
    capture_method = ""
    while capture_method not in ['size', 'protocol']:
        print("Choose the capture method:")
        print("1. Size")
        print("2. Protocol")
        capture_choice = input("Enter 1 or 2: ")
        if capture_choice == '1':
            capture_method = 'size'
        elif capture_choice == '2':
            capture_method = 'protocol'

    if capture_method == 'size':
        operator = ""
        while operator not in ['greater', 'less']:
            print("Choose an operator:")
            print("1. Greater")
            print("2. Less")
            operator_choice = input("Enter 1 or 2: ")
            if operator_choice == '1':
                operator = 'greater'
            elif operator_choice == '2':
                operator = 'less'

        size = 0
        while True:
            size_input = input("Enter packet size in bytes: ")
            print('please wait, this may take a few minutes')
            try:
                size = int(size_input)
                break
            except ValueError:
                print("Please enter a number.")

        packets = sniff(timeout=10)  # Capturing packets

        filtered = packet_size_filter(size, packets, operator)

    else:
        print("Enter protocols separated by commas. For example, if you want to capture packets with IP and TCP protocols, enter: TCP,IP")
        chosen_protocols = input("Enter protocol(s): ")
        print('Please wait, this may take a few minutes')

        packets = sniff(timeout=10)  # Capturing packets

        filtered = protocol_filter(packets, chosen_protocols)

    print(f"Packets found: {len(filtered)}")

    # Display the found packets
    for pkt in filtered:
        print(f"Packet size: {len(pkt)} bytes")
        print(pkt.summary())


if __name__ == "__main__":
    main()
input('')
