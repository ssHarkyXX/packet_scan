import subprocess
subprocess.run('pip install scapy', shell=True)
file_path = input("enter the path to the file ps: ")

try:
    # Запуск файла, путь к которому ввел пользователь
    subprocess.run(['python', file_path.strip('"')], shell=True)
    
    input("press enter to exit")
except FileNotFoundError:
    print("File Not Found.")
except Exception as e:
    print(f"Error: {e}")
